layer = []
affine_shape = []
active = []
layer_weight_index = []

X = None   # Save X of neural network
target = None   # Save target of neural network
X_test = None
T_test = None

Loss_list = []     # Record the change in loss
Validation_loss_list = []   # Record the change in validation loss
Epoch_list = []    # Record the change in Epoch
Acc_list = []      # Record the change in accuracy