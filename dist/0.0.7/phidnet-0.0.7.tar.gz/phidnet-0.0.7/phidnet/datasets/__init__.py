__all__ = ['mnist']


from phidnet.datasets import *